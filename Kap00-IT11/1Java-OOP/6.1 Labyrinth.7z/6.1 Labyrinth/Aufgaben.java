import javax.swing.*;

/**
 * Bitte ergänzen Sie hier die Methoden aufgabeC bis aufgabeM
 */

public class Aufgaben
{
    public static void aufgabeA()
    {
        // Deklaration einer Variablen mit dem Namen jackFarrow,
        // die ein Objekt des Typs Schatzsucher aufnehmen kann.
        Schatzsucher jackSparrow;

        // Erzeugung eines Objektes der Klasse Schatzsucher
        // und Zuweisung an die Variable jackFarrow
        jackSparrow = new Schatzsucher();

        // Alternativer Code:
        // Die beiden obigen Zeilen könnte man auch in einer Zeile zusammenfassen:
        // Schatzsucher jackSparrow = new Schatzsucher();
        
        // Der Schatzsucher Jack Sparrow bewegt sich um 2 Schritte nach links.
        jackSparrow.geheNachLinks(2);
        
        // to do:  Vervollständigen die Methode AufgabeA, so dass der Schatzsucher Jack Sparrow
        //         in nur 37 Schritten sein Ziel erreicht!
    }

    public static void aufgabeB()
    {
        // Deklaration einer Variablen mit dem Namen hugo,
        // die ein Objekt des Typs UnsichtbarerGeist aufnehmen kann.
        UnsichtbarerGeist hugo = new UnsichtbarerGeist();

        // to do:  Versuchen Sie herauszufinden, wo sich der Geist befindet
        //         und führen Sie ihn in nur 8 Schritten in seine Schatztruhe zurück!
        hugo.geheNachRechts();
    }    
    
    public static void aufgabeC()
    {
        // Deklaration der lokalen Variablen robo1,
        // die ein Objekt des Typs Roboter aufnehmen kann.

        
        // Erzeugung eines neuen Objektes der Klasse RoboterGruen
        // durch Konstruktoraufruf
        // und Zuweisung an die Variable robo1

        
        // Methodenaufruf der Methode geheNachUnten
        // des Obejektes robo1 ohne Argument
        

        // Methodenaufruf der Methode geheNachUnten mit Argument 2

        
        // to do:  Vervollständigen die Methode aufgabeC, sodass der Roboter robo1
        //         in nur 8 Schritten sein Ziel erreicht!

    }

    public static void aufgabeD()
    {
        // Deklaration der beiden lokalen Variablen schaf und wolf
        // und Zuweisung zweier neuer Objekte der Klassen Schaf und Wolf

        
        // to do:  Vervollständigen die Methode aufgabeD, sodass das Schaf und der Wolf
        //         ihren Platz tauschen, ohne dass der Wolf das Schaf auffressen kann.
    }
    
    public static void aufgabeE()
    {
        SokobanE sokoban = new SokobanE();

        sokoban.geheNachRechts();
        sokoban.geheNachOben();
        sokoban.geheNachLinks();
        sokoban.geheNachUnten();
        sokoban.geheNachLinks();
        sokoban.geheNachOben();
    }

    public static void aufgabeF()
    {
        SokobanF sokoban = new SokobanF();

        // to do
    }

    public static void aufgabeG()
    {
        SokobanG sokoban = new SokobanG();

        // to do
    }

    public static void aufgabeH()
    {
        SokobanH sokoban = new SokobanH();

        // to do
    }

    public static void aufgabeI()
    {
        SokobanI sokoban = new SokobanI();

        // to do
    }

    public static void aufgabeJ()
    {
        SokobanJ sokoban = new SokobanJ();

        // to do
    }

    public static void aufgabeK()
    {
        SokobanK sokoban = new SokobanK();

        // to do
    }

    public static void aufgabeL()
    {
        SokobanL sokoban = new SokobanL();

        // to do
    }

    public static void aufgabeM()
    {
        SokobanM sokoban = new SokobanM();

        // to do
    }
}
