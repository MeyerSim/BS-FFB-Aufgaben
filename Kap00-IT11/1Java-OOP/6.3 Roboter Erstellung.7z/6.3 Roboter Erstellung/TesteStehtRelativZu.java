import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class TesteStehtRelativZu.
 *
 * @author  (Bichler)
 * @version (Nov 2019)
 */
public class TesteStehtRelativZu
{
    private Roboter robo1;
    private Roboter robo2;
    private Roboter robo3;
    private Roboter ursprung;

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        robo1 = new Roboter(1,2);
        robo2 = new Roboter(3,4);
        robo3 = new Roboter(1,2);
        ursprung = new Roboter();
    }

    @Test
    public void testStehtUeber()
    {
        Roboter robo3 = new Roboter(1,2);
        assertEquals(true, robo1.stehtUeber(new Roboter(1,2.1)));
        assertEquals(false, robo1.stehtUeber(new Roboter(1,1.9)));

        assertEquals(false, robo1.stehtUeber(robo1));
        assertEquals(false, robo1.stehtUeber(robo3));

    }

    @Test
    public void testStehtUnter()
    {
        Roboter robo3 = new Roboter(1,2);
        assertEquals(false, robo1.stehtUnter(new Roboter(1,2.1)));
        assertEquals(true, robo1.stehtUnter(new Roboter(1,1.9)));

        assertEquals(false, robo1.stehtUnter(robo1));
        assertEquals(false, robo1.stehtUnter(robo3));
    }

    @Test
    public void testStehtRechtsVon()
    {
        Roboter robo3 = new Roboter(1,2);
        assertEquals(false, robo1.stehtRechtsVon(new Roboter(1.1,2)));
        assertEquals(true, robo1.stehtRechtsVon(new Roboter(0.9,2)));

        assertEquals(false, robo1.stehtRechtsVon(robo1));
        assertEquals(false, robo1.stehtRechtsVon(robo3));
    }

    @Test
    public void testStehtLinksVon()
    {
        Roboter robo3 = new Roboter(1,2);
        assertEquals(true, robo1.stehtLinksVon(new Roboter(1.1,2)));
        assertEquals(false, robo1.stehtLinksVon(new Roboter(0.9,2)));

        assertEquals(false, robo1.stehtLinksVon(robo1));
        assertEquals(false, robo1.stehtLinksVon(robo3));
    }

}
