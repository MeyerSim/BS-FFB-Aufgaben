/**
 * Die Klasse Auto.
 * 
 * @author (Bichler, Heisel) 
 * @version (2015/16)
 */

public class Auto
{
    // Attribute

    // Konstruktoren

    // Getter

    // Setter

    // allegemeine Methoden

    
}
